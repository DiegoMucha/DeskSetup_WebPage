# Modelo-Front-end-de-e-commerce
1re proyecto de Front-end solo utilizando HTML, CSS y Bootstrap para recrear una pagina e-commerce de venta de productos. Todo ello en el marco del Curso de fullstack en desarrollo web

Clonar el repositorio y utilizar algun tipo de editor de código como Visual Studio Code con la extensión de Live Server para observar la estructura
